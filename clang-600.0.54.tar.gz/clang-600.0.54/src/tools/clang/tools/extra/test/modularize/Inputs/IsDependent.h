// This header depends on SomeTypes.h for the TypeInt typedef.

typedef TypeInt NewTypeInt;
typedef OtherTypeInt OtherNewTypeInt;
