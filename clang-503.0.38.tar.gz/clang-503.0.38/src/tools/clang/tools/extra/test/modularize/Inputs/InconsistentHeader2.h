// Set up so the declaration in InconsistentSubHeader.h is not defined.
#define SYMBOL2 1
#include "InconsistentSubHeader.h"
