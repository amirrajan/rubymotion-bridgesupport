#ifndef _HEADERGUARDSUB2_H_
#define _HEADERGUARDSUB2_H_
#include "HeaderGuardSubSub.h"
#include "HeaderGuardSubSubDefined.h"
#endif // _HEADERGUARDSUB2_H_
