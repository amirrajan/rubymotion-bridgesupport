int *global_p = 0;
// CHECK: int *global_p = nullptr;
