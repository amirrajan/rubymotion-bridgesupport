// Assumes prefix file is used.

@interface A : NSString
-(void) f0;
@end

@implementation A
-(void) f0 {}
@end
