﻿namespace LLVM.ClangFormat
{
    static class PkgCmdIDList
    {
        public const uint cmdidClangFormat = 0x100;
    };
}