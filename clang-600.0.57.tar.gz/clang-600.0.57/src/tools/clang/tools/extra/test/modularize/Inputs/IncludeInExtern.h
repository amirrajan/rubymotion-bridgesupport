extern "C" {
  #include "Empty.h"
}
