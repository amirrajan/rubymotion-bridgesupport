void foo() {
  int *p = 0;
}
