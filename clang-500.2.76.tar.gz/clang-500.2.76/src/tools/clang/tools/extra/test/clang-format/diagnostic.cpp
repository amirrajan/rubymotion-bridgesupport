// RUN: clang-format 2>&1 >/dev/null %s |FileCheck %s

}
// CHECK: diagnostic.cpp:[[@LINE-1]]:1: error: unexpected '}'
