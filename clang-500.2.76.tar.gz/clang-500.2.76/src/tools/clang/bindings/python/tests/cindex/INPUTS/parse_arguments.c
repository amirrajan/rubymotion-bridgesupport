int DECL_ONE = 1;
int DECL_TWO = 2;
