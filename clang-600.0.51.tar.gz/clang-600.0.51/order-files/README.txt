This directory contains tools for automatically generating the Clang order file.
