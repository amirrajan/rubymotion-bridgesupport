void f0(void) {}
