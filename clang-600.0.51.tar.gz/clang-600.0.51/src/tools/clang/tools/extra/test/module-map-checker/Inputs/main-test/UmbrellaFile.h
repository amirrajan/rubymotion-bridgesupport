#define UMBRELLA_HEADER 1
#include "UmbrellaInclude1.h"
#include "UmbrellaInclude2.h"
