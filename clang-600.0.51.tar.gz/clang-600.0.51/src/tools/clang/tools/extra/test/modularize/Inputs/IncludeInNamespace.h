namespace MyNamespace {
  #include "Empty.h"
}
