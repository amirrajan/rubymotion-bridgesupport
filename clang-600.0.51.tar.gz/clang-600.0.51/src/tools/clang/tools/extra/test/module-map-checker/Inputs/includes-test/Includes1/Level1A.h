#define MACRO_1A 1
