#define myns nsblah

namespace nsblah {
struct MyType {
};

} // namespace nsblah
